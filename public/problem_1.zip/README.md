# Primeiro Positivo Faltante

Será dado um array com $N$ elementos. A sua tarefa é dizer qual o menor inteiro, maior que zero, que não existe na sequencia.

## Input

Na primeira linha será dado um inteiro $N$ $(1<= N <= 10^7)$.
Na próxima linha serão dados $N$ inteiros $a_i$ $(-10^8 <= a_i <= 10^8)$.

## Output

Deve ser impresso o menor inteiro, maior que zero, que não está no vetor.